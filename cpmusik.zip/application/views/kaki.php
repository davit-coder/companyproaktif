<div class="col-md-6 offset-md-3 row-divider">
          <p>Copyright &copy 2019 Media Musik Proaktif</p>
          </div>     