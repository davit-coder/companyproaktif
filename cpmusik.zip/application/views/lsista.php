<div id="modal5" class="modal modal-fixed-footer">
  <div id="content-lsista" class="modal-content">
    <h4>Lsista</h4>
    <hr width="75%"></hr>
    <img src="asset/img/profil/avatar-Lsista.png">
       <p><span><h3>Hits Single:</h3>
        	1. Lanangan Ra Mutu<br>
        	2. Jalaranku<br>
        	3. Mangan Ra Njaluk Koe<br>
        	<br><br><br>
        	<h3>Sosmed :</h3>
        	-. Instagram : 6.926<br>
        	-. Youtube : 50.086 <br>
    		<br>

    		@rizkanalurisa : 9.181|@salsyabilla.aptr : 6.628<br>
    		

</span></p>
  </div>

</div>