<div id="modal17" class="modal modal-fixed-footer">
  <div id="news1" class="modal-content">
    <h4>SINGLE TERBARU "BRILLANTS" berjudul "JARAK"</h4>
    <hr width="75%"></hr>
    <img src="<?php echo base_url() ?>asset/img/news/brilants.jpg">
        <p><span>
<p style="text-align: center;"><strong><span style="text-decoration: underline;">BRILLANTS - JARAK</span></strong></p>
<p style="text-align: center;">Lagu ini bercerita tentang hubungan jarak jauh atau yang sering kita sebut LDR, kalau biasanya dalam suatu hubungan jarak jauh konflik ditekankan pada cerita perselingkuhan dan cara saling mempertahankan, bedanya dalam lagu jarak alur cerita ditekankan pada keikhlasan dimana sang pria merelakan wanitanya untuk bahagia bersama orang lain yang selalu ada di dekatnya di sana, seperti yang tertuang dalam lirik lagunya di bawah ini.</p>
<p style="text-align: center;"><strong>Brillants - Jarak</strong></p>
<p style="text-align: center;"><em>Mengapa kita selalu berpura -pura</em></p>
<p style="text-align: center;"><em>Seolah kita sanggup menjalani nya</em></p>
<p style="text-align: center;"><em>Cinta kita tlah lemah terbentang jarak jauh</em></p>
<p style="text-align: center;"><em>Kutahu engkau pasti merasa sepi</em></p>
<p style="text-align: center;"><em>Dihajar rindu yang tak kenal letih</em></p>
<p style="text-align: center;"><em>Tak kusalahkan engkau jika kau pergi berselingkuh</em></p>
<p style="text-align: center;"><strong>Reff :</strong></p>
<p style="text-align: center;"><em>Disaat engkau merasa lelah butuh pundak tuk bersandar</em></p>
<p style="text-align: center;"><em>Ku rela jika seseorang disana mampu menggantikanku membahagiakanmu</em></p>
<p style="text-align: center;"><em>Jika disana kau temukan nyaman mu jangan pikirkan aku</em></p>
<p style="text-align: center;"><em>Ku rela semua yang terbaik untukmu bahagiamu jadi bahagiaku</em></p>
<p style="text-align: center;"><strong>Song 2</strong></p>
<p style="text-align: center;"><em>Terkadang ucapan selamat pagi dan malam</em></p>
<p style="text-align: center;"><em>Tak mampu gantikan hangat sebuah pelukan</em></p>
<p style="text-align: center;"><em>Tak cukup dengan kata tak bisa dengan suara</em></p>
<p style="text-align: center;"><strong>*BacktoReff</strong></p>
&nbsp;
<p style="text-align: center;"><em><strong>Songwriter : Reno Rois</strong></em></p>
<p style="text-align: center;"><em><strong>Composer : Brillants</strong></em></p>
<p style="text-align: center;"><em><strong>Mixing &amp; Mastering : Danny Maretta</strong></em></p>
<p style="text-align: center;"><em><strong>Artist : Brillants</strong></em></p>
<p style="text-align: center;"><em><strong>Label : Proaktif</strong></em></p>
<p style="text-align: center;"><em><strong>Management : Marfins</strong></em></p>
<br>
Official Music Video "<b>JARAK</b>" sudah tersedia di YouTube: <br>
<a href="http://bit.ly/BrillantsJarakClip" target="_blank" rel="noopener"> YOUTUBE JARAK DARI BRILLANTS</a><br><br>

<b>Aktifkan RBT <span lang="EN-US">"<strong>JARAK</strong>"</span> dengan cara: </b><br>

Telkomsel : Ketik <b>JRKCI </b>ke 1212 <br>
XL : Ketik <b>34138869 </b>kirim ke 1818 <br>
Indosat : Ketik <strong>MG 53099451 </strong>kirim ke 808 <br><br>

Single <b>"<strong>JARAK</strong>"</b> sudah tersedia pada digital stores berikut ini: <br>

Spotify : <a href="https://spoti.fi/2XX7QBo" target="_blank" rel="noopener" data-saferedirecturl="https://www.google.com/url?q=http://hyperurl.co/7khu4z&amp;source=gmail&amp;ust=1539396856113000&amp;usg=AFQjCNFPMfpUjfaB7wXgX4GLamdsCgGgqg">SPOTIFY</a> <br>
iTunes : <a href="https://apple.co/2Og4SUg" target="_blank" rel="noopener" data-saferedirecturl="https://www.google.com/url?q=http://hyperurl.co/ocu0w5&amp;source=gmail&amp;ust=1539396856113000&amp;usg=AFQjCNE36QwmVzvb4GmjRqEFytxS1KAuzg">iTunes</a> <br>
Langit Musik: <a href="http://bit.ly/2YaMtaR" target="_blank" rel="noopener" data-saferedirecturl="https://www.google.com/url?q=http://hyperurl.co/7khu4z&amp;source=gmail&amp;ust=1539396856113000&amp;usg=AFQjCNFPMfpUjfaB7wXgX4GLamdsCgGgqg">Langit Musik</a> <br>
Deezer: <a href="http://bit.ly/2K3w0R3" target="_blank" rel="noopener" data-saferedirecturl="https://www.google.com/url?q=http://hyperurl.co/7khu4z&amp;source=gmail&amp;ust=1539396856113000&amp;usg=AFQjCNFPMfpUjfaB7wXgX4GLamdsCgGgqg">Deezer</a>

&nbsp;</span></p>
  </div>

</div>