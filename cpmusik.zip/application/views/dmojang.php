<div id="modal6" class="modal modal-fixed-footer">
  <div id="content-mojang" class="modal-content">
    <h4>d'Mojang</h4>
    <hr width="75%"></hr>
    <img src="asset/img/profil/avaar-dmojang.png">
        <p><span>ProAktif menghidupkan kembali sebuah girlband dangdut yang telah melahirkan banyak karya untuk musik dangdut Indonesia, D’MOJANG.

		Setelah melalui banyak tahapan audisi dan proses tempaan sejak akhir tahun 2018, akhirnya D’MOJANG kembali dengan sebuah formasi baru yang saat ini digawangi oleh :

		<br>Imel, Gynna, Danti, dan Attria.</span></p>
  </div>

</div>