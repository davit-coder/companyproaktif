<!DOCTYPE html>
<html lang="en">

<head>

  <?php $this->load->view("admin/_partials/head.php") ?>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
    <div id="wrapper">

    <?php $this->load->view("admin/_partials/sidebar.php") ?>
  <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
    <div id="content">
    <?php $this->load->view("admin/_partials/navbar.php") ?>

<div class="container-fluid">
    <?php $this->load->view("admin/_partials/content.php") ?>
</div>
</div>

<!-- Sticky Footer -->
    <?php $this->load->view("admin/_partials/footer.php") ?>

</div>
</div>
    <?php $this->load->view("admin/_partials/scrolltop.php") ?>
    <?php $this->load->view("admin/_partials/modal.php") ?>
    <?php $this->load->view("admin/_partials/js.php") ?>

</body>

</html>
