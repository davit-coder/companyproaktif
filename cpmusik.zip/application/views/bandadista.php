<div id="modal3" class="modal modal-fixed-footer">
  <div id="content-adista" class="modal-content">
    <h4>ADISTA BAND</h4>
    <hr width="75%"></hr>
    <img src="asset/img/profil/avaar-Adista.png">
        <p><span><h3>Hits Single:</h3>
        	1. Ku Tak Bisa<br>
        	2. Cukup Satu Cinta<br>
        	3. SarangHae<br>
        	4. Terluka Karnamu <br>
        	5. Mendua <br><br><br><br>
        	<h3>Sosmed :</h3>
        	-. Instagram : 2.795 <br>
        	-. Twitter : 1.427 <br>
    		-. Facebook: 8202 <br><br>

    		@eky_eriawan : 595|@vin_adista : 2.526 <br>
    		@resaradista : 1.170|@akbaradista : 1.715 <br>

</span></p>
  </div>

</div>