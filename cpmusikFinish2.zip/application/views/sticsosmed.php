<div class="container">

 <div class="sticky-container">
  <ul class="sticky">
   <li>
    <a class="btn btn-floating pulse blue" target="_blank" href="https://www.facebook.com/musikproaktif/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
   </li>
   <li>
    <a class="btn btn-floating pulse light-blue lighten-2" target="_blank" 
    href="https://twitter.com/MusikProAktif"><i class="fa fa-twitter" aria-hidden="true"></i></a>
   </li>
   <li>
    <a class="btn btn-floating pulse brown darken-1" target="_blank" href="https://www.instagram.com/musikproaktif/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
   </li>
   <li>
    <a class="btn btn-floating pulse red" target="_blank" href="https://www.youtube.com/user/musikproaktif"><i class="fa fa-youtube" aria-hidden="true"></i></a>
   </li>
   
  </ul>
 </div>
</div>