<div id="modal4" class="modal modal-fixed-footer">
  <div id="content-amor" class="modal-content">
    <h4>DUO AMOR</h4>
    <hr width="75%"></hr>
    <img src="asset/img/profil/avatar-amor.png">
        <p><span><h3>Hits Single:</h3>
        	1. Teman Rasa Pacar<br>
        	2. Pelakor<br>
        	3. Kau Salip Cintaku<br>
        	4. Ora Ono Judule <br>
        	5. Goyang 80jt<br><br><br><br>
        	<h3>Sosmed :</h3>
        	-. Instagram : 4.559 <br>
        	-. Twitter : 597 <br>
    		<br>

    		@refty_duoamor : 30.4k|@yuyun_duoamor : 6.977 <br>
    		

</span></p>
  </div>

</div>