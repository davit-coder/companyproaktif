<div id="modal1" class="modal modal-fixed-footer">
  <div id="content-trio" class="modal-content">
    <h4>TRIO MACAN</h4>
    <hr width="75%"></hr>
    <img src="asset/img/profil/avaar-Triomacan.png">
        <p><span>Trio Macan adalah grup vokal dangdut asal Jombang Jawa Timur yang terdiri dari :
        <br>Lia Amalia, Chacha Sherly dan Dara Rafika.
        <br></span></p>
  </div>

</div>