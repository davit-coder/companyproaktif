<div class="col-md-6 offset-md-3 row-divider">
          <p>Copyright &copy; <?php echo SITE_NAME ." ". (int)date('Y') ?></p>
          </div>     