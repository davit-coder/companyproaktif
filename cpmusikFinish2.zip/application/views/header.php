
<div class="navbar-fixed">
          <nav id="head">
            <div class="container bar">
              <div class="nav-wrapper">
                <a id= "logo" href="http://localhost/cpmusik/" class="brand-logo"><img src="<?php echo base_url() ?>asset/img/logoproaktif/logoproaktif.png"></a>
                <a href="#" data-activates="mobile-nav" class="button-collapse"><i class="material-icons">menu</i></a>
                <ul class="right hide-on-med-and-down">
                  <li><a class = "klik" href="#about"><b>ABOUT</b></a></li>
                  <li><a class = "klik" href="#artist"><b>ARTIST</b></a></li>
                  <li><a class = "klik" href="#news"><b>NEWS</b></a></li>
                  <li><a class = "klik" href="#contact"><b>CONTACT US</b></a></li>
                  <li><a class = "link" href="http://localhost/cpmusik/catalogue"><b>PRODIGI PUBLISHING</b></a></li>
                </ul>
              </div>
            </div>
          </nav>
      </div>

      <!-- sidenav -->
      <ul class="side-nav" id="mobile-nav">
        <li><a href="#about"><b>ABOUT</b></a></li>
        <li><a href="#artist"><b>ARTIST</b></a></li>
        <li><a href="#news"><b>NEWS</b></a></li>
        <li><a href="#contact"><b>CONTACT US</b></a></li>
        <li><a href="http://localhost/cpmusik/catalogue"><b>PRODIGI PUBLISHING</b></a></li>
      </ul>
