<div id="modal7" class="modal modal-fixed-footer">
  <div id="content-elvira" class="modal-content">
    <h4>ELVIRA</h4>
    <hr width="75%"></hr>
    <img src="asset/img/profil/avatar-elvira.png">
        <p><span>Elvira, seorang pendatang baru di industri musik dangdut tanah air.

		Memulai kiprahnya sebagai penyanyi panggungan, Elvira pantang menyerah demi menemukan jalannya di kancah musik nasional.

		Ditemukan pada satu ajang pencarian bakat yang dilakukan oleh ProAktif dan didukung penuh oleh Bens Radio, Elvira berhasil menyabet posisi juara kedua.</span></p>
  </div>

</div>