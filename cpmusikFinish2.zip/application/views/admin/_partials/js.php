  <script src="<?php echo base_url() ?>asset/js/ckeditor/ckeditor.js"></script>

  <script>
    CKEDITOR.replace("editor",{
       language: 'eng',
    uiColor: '#4e73df',
    height : '600'
    });
  </script>